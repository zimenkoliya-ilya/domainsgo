
<?php $__env->startSection('title','account|dashboard'); ?>
<?php $__env->startSection('css'); ?>
<style>
 .sticky-offset {
    top: 56px;
}

#body-row {
    margin-left:0;
    margin-right:0;
}
#sidebar-container {
    min-height: 70vh;   
    background-color: #333;
    padding: 0;
}

/* Sidebar sizes when expanded and expanded */
.sidebar-expanded {
    width: 230px;
}
.sidebar-collapsed {
    width: 60px;
}

/* Menu item*/
#sidebar-container .list-group a {
    height: 50px;
    color: white;
}

/* Submenu item*/
#sidebar-container .list-group .sidebar-submenu a {
    height: 45px;
    padding-left: 30px;
}
.sidebar-submenu {
    font-size: 0.9rem;
}

/* Separators */
.sidebar-separator-title {
    background-color: #333;
    height: 35px;
}
.sidebar-separator {
    background-color: #333;
    height: 25px;
}
.logo-separator {
    background-color: #333;    
    height: 60px;
}

/* Closed submenu icon */
#sidebar-container .list-group .list-group-item[aria-expanded="false"] .submenu-icon::after {
  content: " \f0d7";
  font-family: FontAwesome;
  display: inline;
  text-align: right;
  padding-left: 10px;
}
/* Opened submenu icon */
#sidebar-container .list-group .list-group-item[aria-expanded="true"] .submenu-icon::after {
  content: " \f0da";
  font-family: FontAwesome;
  display: inline;
  text-align: right;
  padding-left: 10px;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <div class="row" id="body-row">
    <?php echo $__env->make('include.account_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- MAIN -->
    <div class="col py-3 bg-grey">
         <?php if(count($errors) > 0): ?>
            <div class = "alert alert-danger fade show">
                <button type="button" class="close" data-dismiss="alert">&times;</button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="card" style="padding:10px;">
            <div class="row">
                <div class="col-md-1"></div>
                <div class="col-md-10">
                    <br>
                    <form method="post" action="<?php echo e(route('account.domains_upload', $domains->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="form-group col-md-6" >
                                <label for="exampleInputPassword1">Domain</label>
                                <p><?php echo e($domains->domain); ?>.<?php echo e($domains->extention); ?></p>
                            </div>
                            <div class="form-group col-md-6" >
                                <label for="exampleInputPassword1">Name</label>
                                <input type="name" class="form-control" id="name" placeholder="Name" name="name" value="<?php echo e($domains->name); ?>">
                            </div>
                        </div>
                        <div class="row">
                          <div class="form-group col-md-6" >
                            <label for="exampleInputPassword1">Email</label>
                            <input type="email" class="form-control" id="email" placeholder="Email" name="email" value="<?php echo e($domains->email); ?>">
                          </div>
                          <div class="form-group col-md-6" >
                                <label for="exampleInputPassword1">Status</label>
                                <div class="form-group">
                                    <select class="form-control" id="sel1" name="status">
                                        <?php if($domains->status == "private"): ?>
                                        <option value="private" selected>private</option>
                                        <?php else: ?>
                                        <option value="private">private</option>
                                        <?php endif; ?>
                                        <?php if($domains->status == "open"): ?>
                                        <option value="open" selected>open</option>
                                        <?php else: ?>
                                        <option value="open">open</option>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                          <div class="form-group col-md-6" >
                            <label for="exampleInputPassword1">Address</label>
                            <input type="text" class="form-control" id="email" placeholder="Address" name="address" value="<?php echo e($domains->address); ?>">
                          </div>
                          <div class="form-group col-md-6" >
                            <label for="exampleInputPassword1">State</label>
                            <input type="text" class="form-control" id="state" placeholder="State" name="state" value="<?php echo e($domains->state); ?>">
                          </div>
                        </div>
                         <div class="row">
                          <div class="form-group col-md-6" >
                            <label for="exampleInputPassword1">City</label>
                            <input type="text" class="form-control" id="email" placeholder="City" name="city" value="<?php echo e($domains->city); ?>">
                          </div>
                          <div class="form-group col-md-6" >
                            <label for="exampleInputPassword1">ZIP</label>
                            <input type="text" class="form-control" id="zip" placeholder="ZIP" name="zip" value="<?php echo e($domains->zip); ?>">
                          </div>
                        </div>
                        <div class="row">
                          <div class="form-group col-md-6" >
                            <label for="exampleInputPassword1">IP Address 1</label>
                            <input type="text" class="form-control" id="ns1" placeholder="IP Address 1" name="ns1" value="<?php echo e($domains->ns1); ?>">
                          </div>
                          <div class="form-group col-md-6" >
                            <label for="exampleInputPassword1">IP Address 2</label>
                            <input type="text" class="form-control" id="ns2" placeholder="IP Address 2" name="ns2" value="<?php echo e($domains->ns2); ?>">
                          </div>
                        </div>
                         <div class="row">
                          <div class="form-group col-md-6" >
                            
                          </div>
                          <div class="form-group col-md-6" >
                             <a style="float:right;">
                                <button type="submit" style="border-radius:50%;"><div><i class="material-icons" style=font-size:45px;>cloud_upload</i></div></button>
                            </a>
                          </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-1"></div>
            </div>
        </div>
    </div>
    <!-- Main Col END -->

</div>   

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
$('#body-row .collapse').collapse('hide'); 

// Collapse/Expand icon
$('#collapse-icon').addClass('fa-angle-double-left'); 

// Collapse click
$('[data-toggle=sidebar-colapse]').click(function() {
    SidebarCollapse();
});

function SidebarCollapse () {
    $('.menu-collapsed').toggleClass('d-none');
    $('.sidebar-submenu').toggleClass('d-none');
    $('.submenu-icon').toggleClass('d-none');
    $('#sidebar-container').toggleClass('sidebar-expanded sidebar-collapsed');
    
    // Treating d-flex/d-none on separators with title
    var SeparatorTitle = $('.sidebar-separator-title');
    if ( SeparatorTitle.hasClass('d-flex') ) {
        SeparatorTitle.removeClass('d-flex');
    } else {
        SeparatorTitle.addClass('d-flex');
    }
    
    // Collapse/Expand icon
    $('#collapse-icon').toggleClass('fa-angle-double-left fa-angle-double-right');
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/domains/resources/views/user/account/domains_edit.blade.php ENDPATH**/ ?>