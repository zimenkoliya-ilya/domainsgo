
<?php $__env->startSection('title','domainchecking'); ?>
<?php $__env->startSection('content'); ?>
<div class="main-content-wrapper">

	<section class="crumina-stunning-header stunning-header-bg7 pb60">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 m-auto align-center">
					<div class="page-category">
						<a href="#" class="page-category-item text-white">Domains</a>
					</div>
					<h1 class="page-title text-white">FIND A GREAT DOMAIN</h1>
					<p class="page-text text-white">Volutpat est velit egestas dui id ornare arcu odio ut. Gravida in fermentum et sollicitudin ac orci. Massa ultricies mi quis hendrerit.</p>
					<form class="mt-5 mb-4" action="<?php echo e(route('search')); ?>" method="get">
						<div class="input-btn--inline">
							<input class="input--white" type="text" placeholder="Choose your new .GO Domain" name="domain">
							<button type="submit" class="crumina-button button--dark button--l">Check It</button>
						</div>
					</form>
					<div class="fw-medium fs-14 c-yellow">.COM domains are just $11.99/year and include a <a class="c-yellow text-decoration-underline" href="#">FREE Private Registration</a></div>
				</div>
			</div>
		</div>
	</section>

	<div class="crumina-breadcrumbs breadcrumbs--lime-themes">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<ul class="breadcrumbs">
						<li class="breadcrumbs-item">
							<a href="index.html">Home</a>
						</li>
						<li class="breadcrumbs-item active">
							<span>Domains</span>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>

	<section class="large-section-padding bg-grey">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-4 col-sm-12 col-xs-12 mb-4 mb-lg-0">
					<div class="crumina-module crumina-domain-filter-panel">
						<h5>DOMAIN EXTENSION FILTER</h5>
						<form class="mb-4 mt-4">
							<input class="input--grey input--squared" type="text" placeholder="Search...">
						</form>
						<div class="checkbox checkbox--style3 mb-4">
							<label>
								<input type="checkbox" name="optionsCheckboxes2" checked>
								Show all
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes1">
								<span class="dot"></span>
								com
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes3">
								<span class="dot"></span>
								net
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes4">
								<span class="dot"></span>
								pro
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes5">
								<span class="dot"></span>
								vip
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes6">
								<span class="dot"></span>
								blog
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes7">
								<span class="dot"></span>
								store
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes8">
								<span class="dot"></span>
								education
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes9">
								<span class="dot"></span>
								cc
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes10">
								<span class="dot"></span>
								name
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes11">
								<span class="dot"></span>
								me
							</label>
						</div>
						<div class="checkbox checkbox--style3">
							<label>
								<input type="checkbox" name="optionsCheckboxes12">
								<span class="dot"></span>
								click
							</label>
						</div>
						<button type="button" class="crumina-button button--blue button--l mt-4 w-100">APPLY</button>
					</div>
				</div>
				<div class="col-lg-9 col-md-8 col-sm-12 col-xs-12">
					<h2 class="align-center">SEARCH RESULT</h2>
					<p class="fs-18 fw-medium align-center">Lectus urna duis convallis convallis tellus orci a scelerisque semper eget.</p>
					<table class="table--style3 mt-5">
						<thead>
						<tr>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
						</tr>
						</thead>
						<tbody>
						    
						<?php if(count($project)>0): ?>
    						<?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    						    <tr class="<?php echo e($temp->name?'already-taken':''); ?>">
    							<td>
    							    <?php echo e($temp['domain']); ?> 
        							<?php if($temp->status): ?>
        							<span class="label-category label--yellow">Private</span>
        							<?php endif; ?>
    							</td>
    							<td>
    							    <?php if($temp->name): ?>
    							    
    							    <?php else: ?>
    							    <?php echo e($temp['price']); ?>

    							    <?php endif; ?>
    							</td>
    							<td>
    							    <?php if($temp->name): ?>
    							    <a href="<?php echo e(route('register_info', [$temp->id, $domain])); ?>" class="crumina-button button--lime button--xs button--bordered w-100" style="color:deeppink; float:right;">Who Is?</a>
    							    <?php else: ?>
    							    <a href="#" class="crumina-button button--lime button--xs button--bordered w-100" style="float:right; ">Order Now</a>
    							    <?php endif; ?>
    							</td>
    							<td>
    							    <?php if($temp->name): ?>
    							    <?php else: ?>
    							    <div id="cart_disable">
    							        <i class="material-icons cart" style="font-size:30px; float:right; cursor:pointer;" onclick="add_cart(this, <?php echo e($temp->id); ?>)">add_shopping_cart</i>    
    							    </div>
    							    
    							    <?php endif; ?>
    							</td>
    						    </tr>
    						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						        <tr>
						            <td>No Result</td>
						        </tr>
						<?php endif; ?>
						
						</tbody>
					</table>
					<div>
					    <form id="form" action="<?php echo e(route('checkout')); ?>" method="post">
					        
					        <button type="submit" class="btn btn-success" style="float:right; font-size:24px; display:none;" id="checkout">
    				        CheckOut <i class="material-icons" style="font-size:21px;">add_shopping_cart</i>
    				        <span class="badge badge-pill badge-primary" id="item_number">4</span>
				            </button>  
					    </form>
					</div>
					
				</div>
			        
			</div>
		</div>
	</section>
    
	<section class="large-section-padding">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ml-auto mr-auto mb-5 align-center">
					<h2>3 TIPS TO FIND THE IDEAL DOMAIN NAME</h2>
					<p class="fs-18 fw-medium">Volutpat est velit egestas dui id ornare arcu odio ut. Gravida in fermentum et sollicitudin ac orci. Massa ultricies mi quis hendrerit.</p>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 mb-4 mb-lg-0">
					<div class="crumina-module crumina-info-box info-box--with-number">

						<div class="info-box-title">1</div>

						<div class="info-box-content">
							<p class="info-box-text">Sollicitudin ac orci phasellus egestas. Urna nunc id cursus metus aliquam eleifend. Neque vitae tempus quam pellentesque volutpat.</p>
						</div>

					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 mb-4 mb-lg-0">
					<div class="crumina-module crumina-info-box info-box--with-number">

						<div class="info-box-title">2</div>

						<div class="info-box-content">
							<p class="info-box-text">Sollicitudin ac orci phasellus egestas. Urna nunc id cursus metus aliquam eleifend. Neque vitae tempus quam pellentesque volutpat.</p>
						</div>

					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 mb-4 mb-lg-0">
					<div class="crumina-module crumina-info-box info-box--with-number">

						<div class="info-box-title">3</div>

						<div class="info-box-content">
							<p class="info-box-text">Sollicitudin ac orci phasellus egestas. Urna nunc id cursus metus aliquam eleifend. Neque vitae tempus quam pellentesque volutpat.</p>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="large-section-padding section-bg3">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-md-12 col-sm-12 col-xs-12 align-center ml-auto mr-auto">


						<img class="mb-4 "  loading="lazy" src="img/demo-content/icons/info-icon20.png" alt="domain">

					<h2>DOMAIN TRANSFERS MADE EASY</h2>
					<p class="fs-18 fw-medium text-white">Purus gravida quis blandit turpis cursus in hac. Sollicitudin aliquam ultrices sagittis orci a scelerisque. Quisque egestas diam in arcu cursus euismod.</p>
					<a href="13_knowledge_base_domain_article_details.html" class="crumina-button button--dark button--l mt-4">TRANSFER YOUR DOMAIN RIGHT NOW!</a>
				</div>
			</div>
		</div>
	</section>

	<section class="large-section-padding">
		<div class="container">
			<div class="row align-items-center">
				<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 mb-4 mb-lg-0">


						<img   loading="lazy" src="img/demo-content/images/image11.png" alt="domain">

				</div>
				<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
					<h2>WHY REGISTER A DOMAIN WITH HOSTSIGHT</h2>
					<div class="row mt-5">
						<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12 mb-4 mb-lg-0">
							<div class="crumina-module crumina-info-box info-box--standard">

								<div class="info-box-thumb">


										<img   loading="lazy" src="img/demo-content/icons/info-icon21.png" alt="icon">

								</div>

								<div class="info-box-content">
									<a href="12_knowledge_base_domain_articles.html" class="h5 info-box-title">Domain Renewal</a>
									<p class="info-box-text">Urna nunc id cursus metus aliquam eleifend. Neque vitae tempus quam pellentesque. Volutpat odio facilisis mauris sit amet massa vitae.</p>
								</div>

							</div>
						</div>
						<div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
							<div class="crumina-module crumina-info-box info-box--standard">

								<div class="info-box-thumb">


										<img   loading="lazy" src="img/demo-content/icons/info-icon22.png" alt="icon">

								</div>

								<div class="info-box-content">
									<a href="12_knowledge_base_domain_articles.html" class="h5 info-box-title">Domain Locking</a>
									<p class="info-box-text">Egestas tellus rutrum tellus pellentesque eu tincidunt tortor aliquam nulla condimentum lacinia quis vel eros donec ac odio.</p>
								</div>

							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section class="small-section-padding section-bg5">
		<div class="container">
			<div class="row">
				<div class="col-lg-8 col-md-10 col-sm-12 col-xs-12 m-auto">
					<div class="crumina-module crumina-info-box info-box--inline">
						<div class="info-box-thumb">


								<img   loading="lazy" src="img/demo-content/icons/info-icon23.png" alt="icon">

						</div>
						<div class="info-box-content">
							<h4 class="info-box-title text-white">Domain Privacy Protection</h4>
							<p class="info-box-text">Quisque egestas diam in arcu cursus euismod. Lectus urna duis convallis convallis tellus. Sagittis orci a scelerisque purus.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $( document ).ready(function() {
            count_cart();
        });
        function count_cart(){
            var cart_active = document.querySelectorAll('.cart.active');
            
            var cart_length = cart_active.length;
            console.log(cart_length)
            if(cart_length>0){
                document.getElementById("checkout").style.display="block";
            }
            document.getElementById("item_number").innerHTML=cart_length;
            
        }
        function who(){
            document.getElementById("loginpage").click();
        }
        function add_cart(cart, id){
            cart.style.color="green";
            cart.classList.add('active');
            
            let p = document.createElement("INPUT");
            document.getElementById("form").appendChild(p);    
            p.value= id;
            p.name = "carts[]";
            p.type = "hidden";
            count_cart();
            cart.setAttribute("onclick","disabled");
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/domains/resources/views/user/domainchecking/domainchecking.blade.php ENDPATH**/ ?>