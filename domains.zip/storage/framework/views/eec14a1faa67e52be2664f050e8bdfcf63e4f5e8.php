
<?php $__env->startSection('title','search'); ?>
<?php $__env->startSection('content'); ?>


	<section class="large-section-padding bg-grey">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h2 class="align-center">SEARCH RESULT</h2>
				
					<table class="table--style3 mt-5">
						<thead>
						<tr>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
						</tr>
						</thead>
						<tbody>
						    
    						<?php if(count($project)>0): ?>
        						<?php $__currentLoopData = $project; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        						    <tr class="<?php echo e($temp->user_id?'already-taken':''); ?>">
        							<td>
        							    <?php echo e($temp['domain']); ?>.<?php echo e($temp->extention); ?>

            							<span class="label-category label--yellow"><?php echo e($temp->status); ?></span>
        							</td>
        							<td>
        							  
        							</td>
        							<td>
        							    <?php if($temp->status == "private"): ?>
        							    <?php else: ?>
        							    <a href="<?php echo e(route('register_info', [$temp->id, $domain])); ?>" class="crumina-button button--lime button--xs button--bordered w-100" style="color:deeppink; float:right;">Who Is?</a>
        							    <?php endif; ?>
        							</td>
        							<td>
        							    
        							</td>
        						    </tr>
        						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        					<?php endif; ?>
    						<?php $__currentLoopData = $extention; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    						    <tr>
    							<td>
    							    <?php echo e($domain); ?>.<?php echo e($tem->ext); ?>

    							</td>
    							<td>
    							    <?php echo e($tem->price); ?>

    							</td>
    							<td>
    							    <!--<a href="#" class="crumina-button button--lime button--xs button--bordered w-100" style="float:right; ">Order Now</a>-->
    							</td>
    							<td>
    							    <div id="cart_disable">
    							        <i class="material-icons cart" style="font-size:30px; float:right; cursor:pointer;" onclick="add_cart(this, <?php echo e($tem->id); ?>, '<?php echo e($domain); ?>')">add_shopping_cart</i>    
    							    </div>
    							</td>
    						    </tr>
    						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
					
						
						</tbody>
					</table>
					<!--<div>-->
					<!--    <form id="form" action="<?php echo e(route('checkout')); ?>" method="post">-->
					<!--        <?php echo csrf_field(); ?>-->
					<!--        <button type="submit" class="btn btn-success" style="float:right; font-size:24px;" id="checkout">-->
    	<!--			        CheckOut <i class="material-icons" style="font-size:21px;">add_shopping_cart</i>-->
				 <!--           </button>  -->
					<!--    </form>-->
					<!--</div>-->
					
				</div>
			        
			</div>
		</div>
	</section>
    


</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
    var i = 0;
        
        // function count_cart(){
        //     var cart_active = document.querySelectorAll('.cart.active');
            
        //     var cart_length = cart_active.length;
        //     console.log(cart_length)
        //     if(cart_length>0){
        //         document.getElementById("checkout").style.display="block";
        //         document.getElementById("item_number").style.display = "inline-grid";
        //     }
        //     document.getElementById("item_number").innerHTML=cart_length;
        // }
        function who(){
            document.getElementById("loginpage").click();
        }
        function add_cart(cart, id, domain){
            cart.style.color="green";
            cart.classList.add('active');
            
            // let p = document.createElement("INPUT");
            // document.getElementById("form").appendChild(p);    
            // p.value= id;
            // p.name = "ext[]";
            // p.type = "hidden";
            
            // let domain_name = document.createElement("INPUT");
            // document.getElementById("form").appendChild(domain_name);    
            // domain_name.value= domain;
            // domain_name.name = "domain[]";
            // domain_name.type = "hidden";
            $.ajax({
                type:'POST',
                url:'/home/search/add_cart',
                headers: {'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>' },
                data : {'id' :id,'domain_name':domain},
                success: function(ret){
                    $('#item_number').css('display', 'inline-block');
                }
            });
            var cart_number = document.getElementById("item_number").innerHTML;
            document.getElementById("item_number").innerHTML = Number(cart_number)+1;
            cart.setAttribute("onclick","disabled");
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('include.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/domains/public_html/resources/views/user/search/search.blade.php ENDPATH**/ ?>